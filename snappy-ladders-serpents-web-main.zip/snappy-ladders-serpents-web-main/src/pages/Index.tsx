
import React from 'react';
import { SnakeAndLadders } from '@/components/SnakeAndLadders';

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-b from-violet-50 to-indigo-100 py-8 px-4">
      <div className="container mx-auto">
        <header className="mb-8 text-center">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-bold text-indigo-800 mb-2">Snake and Ladders</h1>
          <p className="text-lg text-indigo-600">The classic board game, digitized and responsive!</p>
        </header>
        
        <main>
          <SnakeAndLadders />
        </main>
        
        <footer className="mt-12 text-center text-sm text-indigo-500">
          <p>&copy; 2025 Snake and Ladders Game</p>
        </footer>
      </div>
    </div>
  );
};

export default Index;
