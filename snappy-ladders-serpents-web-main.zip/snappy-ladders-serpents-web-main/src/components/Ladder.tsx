
import React from 'react';

interface LadderProps {
  start: number;
  end: number;
  boardSize: number;
  getSquarePosition: (square: number) => { row: number; col: number };
}

export const Ladder: React.FC<LadderProps> = ({ start, end, boardSize, getSquarePosition }) => {
  const startPos = getSquarePosition(start);
  const endPos = getSquarePosition(end);
  
  // Calculate absolute positions for SVG
  const startX = (startPos.col + 0.5) * (100 / boardSize);
  const startY = (startPos.row + 0.5) * (100 / boardSize);
  const endX = (endPos.col + 0.5) * (100 / boardSize);
  const endY = (endPos.row + 0.5) * (100 / boardSize);
  
  // Calculate the angle of the ladder
  const angle = Math.atan2(endY - startY, endX - startX) * (180 / Math.PI);
  const distance = Math.sqrt(Math.pow(endX - startX, 2) + Math.pow(endY - startY, 2));
  
  // Calculate number of rungs based on distance
  const numRungs = Math.max(2, Math.floor(distance / 10));
  
  return (
    <svg className="absolute top-0 left-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
      {/* Left rail of ladder */}
      <line
        x1={`${startX - 1}%`}
        y1={`${startY}%`}
        x2={`${endX - 1}%`}
        y2={`${endY}%`}
        stroke="#f97316"
        strokeWidth="1.2%"
        strokeLinecap="round"
      />
      
      {/* Right rail of ladder */}
      <line
        x1={`${startX + 1}%`}
        y1={`${startY}%`}
        x2={`${endX + 1}%`}
        y2={`${endY}%`}
        stroke="#f97316"
        strokeWidth="1.2%"
        strokeLinecap="round"
      />
      
      {/* Ladder rungs */}
      {Array.from({ length: numRungs }, (_, i) => {
        const t = (i + 1) / (numRungs + 1);
        const x = startX + (endX - startX) * t;
        const y = startY + (endY - startY) * t;
        const perpAngle = angle + 90;
        const rungLength = 2;
        const x1 = x - (rungLength * Math.cos(perpAngle * Math.PI / 180));
        const y1 = y - (rungLength * Math.sin(perpAngle * Math.PI / 180));
        const x2 = x + (rungLength * Math.cos(perpAngle * Math.PI / 180));
        const y2 = y + (rungLength * Math.sin(perpAngle * Math.PI / 180));
        
        return (
          <line
            key={i}
            x1={`${x1}%`}
            y1={`${y1}%`}
            x2={`${x2}%`}
            y2={`${y2}%`}
            stroke="#c2410c"
            strokeWidth="0.8%"
          />
        );
      })}
    </svg>
  );
};
