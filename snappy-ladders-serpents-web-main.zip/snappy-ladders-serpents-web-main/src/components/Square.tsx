
import React from 'react';
import { cn } from '@/lib/utils';

interface SquareProps {
  number: number;
  isAlt?: boolean;
}

export const Square: React.FC<SquareProps> = ({ number, isAlt = false }) => {
  return (
    <div className={cn(
      "flex items-center justify-center border border-board-border rounded-sm",
      isAlt ? "bg-board-alt" : "bg-board"
    )}>
      <span className="text-xs sm:text-sm font-semibold text-muted-foreground">
        {number}
      </span>
    </div>
  );
};
