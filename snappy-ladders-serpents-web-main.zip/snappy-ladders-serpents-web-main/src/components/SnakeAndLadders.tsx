
import React, { useState } from 'react';
import { GameBoard } from './GameBoard';
import { DiceRoller } from './DiceRoller';
import { GameControls } from './GameControls';
import { GameInfoPanel } from './GameInfoPanel';
import { StartScreen } from './StartScreen';
import { PlayerSetup } from './PlayerSetup';
import { useGameLogic } from '@/hooks/useGameLogic';
import { ScrollArea } from '@/components/ui/scroll-area';

type GameStage = 'start' | 'setup' | 'playing';

export const SnakeAndLadders: React.FC = () => {
  const [gameStage, setGameStage] = useState<GameStage>('start');
  const [playerNames, setPlayerNames] = useState<string[]>([]);
  
  const {
    boardSize,
    snakes,
    ladders,
    players,
    currentPlayer,
    diceValue,
    isRolling,
    winner,
    gameStatus,
    moveHistory,
    rollDice,
    newGame,
    resetGame,
    setCustomPlayerCount
  } = useGameLogic();

  const handleStartClick = () => {
    setGameStage('setup');
  };

  const handleStartGame = (names: string[]) => {
    setPlayerNames(names);
    setCustomPlayerCount(names.length);
    resetGame();
    setGameStage('playing');
  };

  const handleNewGame = () => {
    setGameStage('setup');
    newGame();
  };

  if (gameStage === 'start') {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <StartScreen onStart={handleStartClick} />
      </div>
    );
  }

  if (gameStage === 'setup') {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <PlayerSetup onStartGame={handleStartGame} />
      </div>
    );
  }

  return (
    <div className="flex flex-col lg:flex-row gap-6 w-full max-w-6xl mx-auto">
      <div className="lg:w-2/3 w-full">
        <GameBoard
          currentPlayer={currentPlayer}
          players={players}
          playerNames={playerNames}
          snakes={snakes}
          ladders={ladders}
          boardSize={boardSize}
          winner={winner}
        />
      </div>
      
      <div className="lg:w-1/3 w-full space-y-6">
        <div className="flex flex-col gap-4 p-4 bg-white rounded-lg shadow-md">
          <DiceRoller
            diceValue={diceValue}
            isRolling={isRolling}
            disabled={gameStatus === 'finished'}
            onRollDice={rollDice}
          />
        </div>
        
        <GameControls
          currentPlayer={currentPlayer}
          playerNames={playerNames}
          gameStatus={gameStatus}
          winner={winner}
          onNewGame={handleNewGame}
        />
        
        <GameInfoPanel>
          <div className="mb-4">
            <h4 className="font-medium text-sm mb-2">Players</h4>
            <div className="grid grid-cols-2 gap-2">
              {playerNames.map((name, index) => (
                <div key={index} className="flex items-center space-x-2 p-2 bg-gray-50 rounded">
                  <div className={`w-3 h-3 rounded-full ${index === 0 ? 'bg-player-1' : index === 1 ? 'bg-player-2' : index === 2 ? 'bg-amber-500' : 'bg-emerald-500'}`}></div>
                  <span className="text-xs font-medium truncate">{name}</span>
                </div>
              ))}
            </div>
          </div>
          
          <div className="mt-4">
            <h4 className="font-medium text-sm mb-2">Move History</h4>
            <ScrollArea className="h-32 w-full rounded-md border">
              <div className="p-2">
                {moveHistory.length > 0 ? (
                  moveHistory.map((move, index) => (
                    <p key={index} className="text-xs py-1 border-b border-gray-100 last:border-0">
                      {move}
                    </p>
                  ))
                ) : (
                  <p className="text-xs text-muted-foreground italic">No moves yet. Roll the dice to start!</p>
                )}
              </div>
            </ScrollArea>
          </div>
        </GameInfoPanel>
      </div>
    </div>
  );
};
