
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

interface GameInfoPanelProps {
  children?: React.ReactNode;
}

export const GameInfoPanel: React.FC<GameInfoPanelProps> = ({ children }) => {
  return (
    <Card className="w-full">
      <CardHeader className="pb-2">
        <CardTitle className="text-xl">Game Info</CardTitle>
        <CardDescription>
          Navigate the board, avoid snakes, climb ladders
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-player-1 rounded-full"></div>
            <span className="text-sm font-medium">Player 1</span>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-player-2 rounded-full"></div>
            <span className="text-sm font-medium">Player 2</span>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-snake rounded-full"></div>
            <span className="text-sm font-medium">Snakes (go down)</span>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-ladder rounded-full"></div>
            <span className="text-sm font-medium">Ladders (go up)</span>
          </div>
          
          <p className="text-sm text-muted-foreground">
            Roll the dice to move. First player to reach 100 wins!
          </p>
        </div>
        
        {children}
      </CardContent>
    </Card>
  );
};
