
import React from 'react';
import { Button } from '@/components/ui/button';
import { PlayCircle } from 'lucide-react';

interface StartScreenProps {
  onStart: () => void;
}

export const StartScreen: React.FC<StartScreenProps> = ({ onStart }) => {
  return (
    <div className="flex flex-col items-center justify-center p-8 bg-white rounded-lg shadow-lg text-center space-y-6 max-w-md mx-auto">
      <h2 className="text-3xl font-bold text-indigo-800">Snake and Ladders</h2>
      <p className="text-lg text-indigo-600">
        The classic board game where players race to the finish, navigating through ladders and avoiding snakes.
      </p>
      
      <div className="space-y-4 w-full">
        <p className="text-gray-600">Ready to roll the dice and start your adventure?</p>
        <Button 
          onClick={onStart} 
          className="w-full bg-indigo-600 hover:bg-indigo-700"
          size="lg"
        >
          <PlayCircle className="mr-2 h-5 w-5" />
          Start Game
        </Button>
      </div>
    </div>
  );
};
