
import React from 'react';
import { Button } from '@/components/ui/button';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface GameControlsProps {
  currentPlayer: number;
  playerNames: string[];
  gameStatus: 'waiting' | 'playing' | 'finished';
  winner: number | null;
  onNewGame: () => void;
}

export const GameControls: React.FC<GameControlsProps> = ({
  currentPlayer,
  playerNames = [],  // Provide default empty array
  gameStatus,
  winner,
  onNewGame
}) => {
  // Check if currentPlayer index is valid before accessing playerNames
  const currentPlayerIndex = currentPlayer - 1;
  const currentPlayerName = playerNames && playerNames.length > currentPlayerIndex && currentPlayerIndex >= 0
    ? playerNames[currentPlayerIndex]
    : `Player ${currentPlayer}`;
    
  // Check if winner index is valid before accessing playerNames for winner
  const winnerIndex = winner ? winner - 1 : null;
  const winnerName = winner && playerNames && playerNames.length > winnerIndex && winnerIndex >= 0
    ? playerNames[winnerIndex]
    : winner ? `Player ${winner}` : null;

  return (
    <div className="flex flex-col gap-4 p-4 bg-white rounded-lg shadow-md">
      <div className="text-center">
        {gameStatus === 'waiting' && (
          <p className="font-medium text-gray-700">Roll the dice to start the game!</p>
        )}
        
        {gameStatus === 'playing' && (
          <p className="font-medium text-gray-700">
            {currentPlayerName}'s turn
          </p>
        )}
        
        {gameStatus === 'finished' && winner && (
          <div className="flex flex-col items-center gap-2">
            <AlertTriangle className="text-yellow-500 w-6 h-6" />
            <p className="font-bold text-lg">
              {winnerName} wins!
            </p>
          </div>
        )}
      </div>
      
      {gameStatus === 'finished' && (
        <Button 
          onClick={onNewGame}
          className="w-full flex items-center gap-2"
        >
          <RefreshCw className="w-4 h-4" />
          New Game
        </Button>
      )}
    </div>
  );
};
