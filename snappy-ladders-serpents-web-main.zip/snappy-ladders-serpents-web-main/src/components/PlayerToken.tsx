
import React from 'react';
import { cn } from '@/lib/utils';

interface PlayerTokenProps {
  playerId: number;
  playerName: string;
  position: number;
  isCurrentPlayer: boolean;
  isWinner: boolean;
  boardSize: number;
  getSquarePosition: (square: number) => { row: number; col: number };
}

export const PlayerToken: React.FC<PlayerTokenProps> = ({
  playerId,
  playerName,
  position,
  isCurrentPlayer,
  isWinner,
  boardSize,
  getSquarePosition
}) => {
  const { row, col } = getSquarePosition(position);
  
  // Calculate the position in percentages for absolute positioning
  const leftPosition = (col + (playerId === 1 ? 0.3 : 0.7)) * (100 / boardSize);
  const topPosition = (row + 0.5) * (100 / boardSize);
  
  const playerColors = {
    1: 'bg-player-1',
    2: 'bg-player-2',
    3: 'bg-amber-500',
    4: 'bg-emerald-500'
  };
  
  // Get display name (first character or first two characters of player name)
  const displayName = playerName.length > 0 ? 
    (playerName.length > 10 ? playerName.substring(0, 2) : playerName.substring(0, 1)) 
    : `P${playerId}`;
  
  return (
    <div
      className={cn(
        "absolute transform -translate-x-1/2 -translate-y-1/2 rounded-full",
        playerColors[playerId as keyof typeof playerColors] || 'bg-player-1',
        "border-2 border-white shadow-md flex items-center justify-center text-white font-bold",
        isCurrentPlayer && "ring-2 ring-yellow-300",
        isCurrentPlayer && !isWinner && "animate-player-move",
        isWinner && "ring-2 ring-yellow-500 animate-pulse",
        "w-[8%] h-[8%] text-[8px] sm:text-xs"
      )}
      style={{
        left: `${leftPosition}%`,
        top: `${topPosition}%`,
      }}
      title={playerName}
    >
      {displayName}
    </div>
  );
};
