
import React from 'react';

interface SnakeProps {
  start: number;
  end: number;
  boardSize: number;
  getSquarePosition: (square: number) => { row: number; col: number };
}

export const Snake: React.FC<SnakeProps> = ({ start, end, boardSize, getSquarePosition }) => {
  const startPos = getSquarePosition(start);
  const endPos = getSquarePosition(end);
  
  // Calculate absolute positions for SVG
  const startX = (startPos.col + 0.5) * (100 / boardSize);
  const startY = (startPos.row + 0.5) * (100 / boardSize);
  const endX = (endPos.col + 0.5) * (100 / boardSize);
  const endY = (endPos.row + 0.5) * (100 / boardSize);
  
  // Calculate control points for curved path
  const midX = (startX + endX) / 2;
  const midY = (startY + endY) / 2;
  const controlX1 = midX + (startY < endY ? 10 : -10);
  const controlY1 = midY - 10;
  const controlX2 = midX - (startY < endY ? 10 : -10);
  const controlY2 = midY + 10;
  
  return (
    <svg className="absolute top-0 left-0 w-full h-full pointer-events-none" xmlns="http://www.w3.org/2000/svg">
      <path
        d={`M ${startX}% ${startY}% C ${controlX1}% ${controlY1}%, ${controlX2}% ${controlY2}%, ${endX}% ${endY}%`}
        fill="none"
        stroke="url(#snakeGradient)"
        strokeWidth="2.5%"
        strokeLinecap="round"
      />
      {/* Snake head */}
      <circle cx={`${endX}%`} cy={`${endY}%`} r="1.5%" fill="#16a34a" />
      
      {/* Define gradient for snake body */}
      <defs>
        <linearGradient id="snakeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%" stopColor="#4ade80" />
          <stop offset="100%" stopColor="#16a34a" />
        </linearGradient>
      </defs>
    </svg>
  );
};
