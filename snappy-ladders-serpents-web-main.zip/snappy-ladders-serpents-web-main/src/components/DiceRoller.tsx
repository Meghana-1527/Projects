
import React from 'react';
import { Button } from '@/components/ui/button';
import { Dice1, Dice2, Dice3, Dice4, Dice5, Dice6 } from 'lucide-react';
import { cn } from '@/lib/utils';

interface DiceRollerProps {
  diceValue: number;
  isRolling: boolean;
  disabled: boolean;
  onRollDice: () => void;
}

export const DiceRoller: React.FC<DiceRollerProps> = ({
  diceValue,
  isRolling,
  disabled,
  onRollDice
}) => {
  const diceIcons = [
    <Dice1 key={1} className="w-12 h-12" />,
    <Dice2 key={2} className="w-12 h-12" />,
    <Dice3 key={3} className="w-12 h-12" />,
    <Dice4 key={4} className="w-12 h-12" />,
    <Dice5 key={5} className="w-12 h-12" />,
    <Dice6 key={6} className="w-12 h-12" />,
  ];

  return (
    <div className="flex flex-col items-center gap-4">
      <div 
        className={cn(
          "w-20 h-20 bg-white rounded-lg shadow-md flex items-center justify-center",
          isRolling && "animate-dice-roll"
        )}
      >
        {diceValue > 0 ? diceIcons[diceValue - 1] : <span className="text-lg font-bold">?</span>}
      </div>
      <Button 
        onClick={onRollDice} 
        disabled={disabled || isRolling}
        className="w-full px-8"
        variant="default"
      >
        {isRolling ? "Rolling..." : "Roll Dice"}
      </Button>
    </div>
  );
};
