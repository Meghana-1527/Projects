
import React from 'react';
import { cn } from '@/lib/utils';
import { Square } from './Square';
import { Snake } from './Snake';
import { Ladder } from './Ladder';
import { PlayerToken } from './PlayerToken';

export type SnakeType = {
  start: number;
  end: number;
};

export type LadderType = {
  start: number;
  end: number;
};

interface GameBoardProps {
  currentPlayer: number;
  players: number[];
  playerNames: string[];
  snakes: SnakeType[];
  ladders: LadderType[];
  boardSize: number;
  winner: number | null;
}

export const GameBoard: React.FC<GameBoardProps> = ({
  currentPlayer,
  players,
  playerNames,
  snakes,
  ladders,
  boardSize,
  winner
}) => {
  const squares = Array.from({ length: boardSize * boardSize }, (_, i) => i + 1);
  
  // Configure board layout - zigzag pattern with 1 at bottom-left and 100 at top-left
  const getSquarePosition = (square: number) => {
    const row = Math.floor((square - 1) / boardSize);
    // For even rows (0-indexed), numbers go left to right
    // For odd rows (0-indexed), numbers go right to left
    const col = row % 2 === 0 
      ? (square - 1) % boardSize 
      : boardSize - 1 - ((square - 1) % boardSize);
    
    // Flip the rows so 1 is at the bottom and 100 is at the top
    const flippedRow = boardSize - 1 - row;
    
    return { row: flippedRow, col };
  };

  return (
    <div className="relative w-full max-w-2xl mx-auto aspect-square bg-board border-2 border-board-border rounded-lg overflow-hidden shadow-lg">
      <div
        className="grid gap-0.5 w-full h-full p-1"
        style={{ gridTemplateColumns: `repeat(${boardSize}, 1fr)` }}
      >
        {squares.map((square) => {
          const { row, col } = getSquarePosition(square);
          const isAlt = (row + col) % 2 === 1;
          
          return (
            <Square 
              key={square} 
              number={square}
              isAlt={isAlt}
            />
          );
        })}
      </div>
      
      {/* Render snakes */}
      {snakes.map((snake, index) => (
        <Snake key={`snake-${index}`} start={snake.start} end={snake.end} boardSize={boardSize} getSquarePosition={getSquarePosition} />
      ))}
      
      {/* Render ladders */}
      {ladders.map((ladder, index) => (
        <Ladder key={`ladder-${index}`} start={ladder.start} end={ladder.end} boardSize={boardSize} getSquarePosition={getSquarePosition} />
      ))}
      
      {/* Render player tokens */}
      {players.map((position, index) => (
        <PlayerToken 
          key={`player-${index}`} 
          playerId={index + 1} 
          playerName={playerNames[index] || `Player ${index + 1}`}
          position={position} 
          isCurrentPlayer={currentPlayer === index + 1}
          isWinner={winner === index + 1}
          boardSize={boardSize}
          getSquarePosition={getSquarePosition}
        />
      ))}
    </div>
  );
};
