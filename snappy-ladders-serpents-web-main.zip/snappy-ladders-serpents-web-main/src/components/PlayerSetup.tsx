
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Plus, Minus, UserCircle, PlayCircle, Edit2 } from 'lucide-react';
import { toast } from '@/components/ui/sonner';

interface PlayerSetupProps {
  onStartGame: (playerNames: string[]) => void;
}

export const PlayerSetup: React.FC<PlayerSetupProps> = ({ onStartGame }) => {
  const [playerCount, setPlayerCount] = useState(2);
  const [playerNames, setPlayerNames] = useState<string[]>(['Player 1', 'Player 2']);
  const [editingIndex, setEditingIndex] = useState<number | null>(null);

  const handlePlayerCountChange = (increment: boolean) => {
    if (increment && playerCount < 4) {
      setPlayerCount(prev => prev + 1);
      setPlayerNames(prev => [...prev, `Player ${playerCount + 1}`]);
    } else if (!increment && playerCount > 2) {
      setPlayerCount(prev => prev - 1);
      setPlayerNames(prev => prev.slice(0, -1));
    }
  };

  const handleNameChange = (index: number, name: string) => {
    const newNames = [...playerNames];
    newNames[index] = name;
    setPlayerNames(newNames);
  };

  const handleStartGame = () => {
    // Validate that all player names are not empty
    const hasEmptyNames = playerNames.some(name => name.trim() === '');
    if (hasEmptyNames) {
      toast.error("All players must have names!");
      return;
    }

    // Check for duplicate names
    const uniqueNames = new Set(playerNames);
    if (uniqueNames.size !== playerNames.length) {
      toast.error("All players must have unique names!");
      return;
    }

    onStartGame(playerNames);
  };

  return (
    <div className="flex flex-col items-center p-6 bg-white rounded-lg shadow-lg space-y-6 max-w-md mx-auto">
      <h2 className="text-2xl font-bold text-indigo-800">Player Setup</h2>
      
      <div className="flex items-center justify-between w-full p-4 bg-indigo-50 rounded-md">
        <span className="font-medium">Number of Players:</span>
        <div className="flex items-center space-x-4">
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => handlePlayerCountChange(false)}
            disabled={playerCount <= 2}
          >
            <Minus className="h-4 w-4" />
          </Button>
          <span className="text-xl font-bold">{playerCount}</span>
          <Button 
            variant="outline" 
            size="icon" 
            onClick={() => handlePlayerCountChange(true)}
            disabled={playerCount >= 4}
          >
            <Plus className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      <div className="w-full space-y-4">
        <h3 className="text-lg font-medium text-indigo-700">Player Names</h3>
        {playerNames.map((name, index) => (
          <div key={index} className="flex items-center space-x-2">
            <div className="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-full bg-player-1 text-white font-bold">
              {index + 1}
            </div>
            {editingIndex === index ? (
              <Input
                value={name}
                onChange={(e) => handleNameChange(index, e.target.value)}
                autoFocus
                onBlur={() => setEditingIndex(null)}
                onKeyDown={(e) => e.key === 'Enter' && setEditingIndex(null)}
                className="flex-grow"
                maxLength={15}
              />
            ) : (
              <div className="flex-grow flex items-center justify-between bg-gray-50 px-3 py-2 rounded-md">
                <div className="flex items-center">
                  <UserCircle className="h-4 w-4 mr-2 text-gray-500" />
                  <span>{name}</span>
                </div>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  onClick={() => setEditingIndex(index)}
                >
                  <Edit2 className="h-4 w-4" />
                </Button>
              </div>
            )}
          </div>
        ))}
      </div>
      
      <Button 
        onClick={handleStartGame} 
        className="w-full mt-6 bg-indigo-600 hover:bg-indigo-700"
        size="lg"
      >
        <PlayCircle className="mr-2 h-5 w-5" />
        Start Game
      </Button>
    </div>
  );
};
