
import { useState, useEffect } from 'react';
import { toast } from '@/components/ui/sonner';
import { SnakeType, LadderType } from '@/components/GameBoard';

// Default game configuration
const DEFAULT_BOARD_SIZE = 10;
const DEFAULT_SNAKES: SnakeType[] = [
  { start: 16, end: 6 },
  { start: 47, end: 26 },
  { start: 49, end: 11 },
  { start: 56, end: 53 },
  { start: 62, end: 19 },
  { start: 64, end: 60 },
  { start: 87, end: 24 },
  { start: 93, end: 73 },
  { start: 95, end: 75 },
  { start: 98, end: 78 }
];
const DEFAULT_LADDERS: LadderType[] = [
  { start: 1, end: 38 },
  { start: 4, end: 14 },
  { start: 9, end: 31 },
  { start: 21, end: 42 },
  { start: 28, end: 84 },
  { start: 36, end: 44 },
  { start: 51, end: 67 },
  { start: 71, end: 91 },
  { start: 80, end: 100 }
];

interface UseGameLogicOptions {
  boardSize?: number;
  snakes?: SnakeType[];
  ladders?: LadderType[];
  playerCount?: number;
}

export const useGameLogic = (options: UseGameLogicOptions = {}) => {
  const {
    boardSize = DEFAULT_BOARD_SIZE,
    snakes = DEFAULT_SNAKES,
    ladders = DEFAULT_LADDERS,
  } = options;
  
  const [playerCount, setPlayerCount] = useState(options.playerCount || 2);
  const [players, setPlayers] = useState<number[]>(Array(playerCount).fill(1));
  const [currentPlayer, setCurrentPlayer] = useState(1);
  const [diceValue, setDiceValue] = useState(0);
  const [isRolling, setIsRolling] = useState(false);
  const [winner, setWinner] = useState<number | null>(null);
  const [gameStatus, setGameStatus] = useState<'waiting' | 'playing' | 'finished'>('waiting');
  const [moveHistory, setMoveHistory] = useState<string[]>([]);
  
  const totalSquares = boardSize * boardSize;
  
  // Update players array when player count changes
  useEffect(() => {
    setPlayers(Array(playerCount).fill(1));
  }, [playerCount]);
  
  // Find a snake at the position
  const findSnake = (position: number) => snakes.find(snake => snake.start === position);
  
  // Find a ladder at the position
  const findLadder = (position: number) => ladders.find(ladder => ladder.start === position);
  
  // Handle player movement
  const movePlayer = (playerIndex: number, steps: number) => {
    const playerPosition = players[playerIndex];
    let newPosition = playerPosition + steps;
    
    // Check if player wins
    if (newPosition === totalSquares) {
      setWinner(playerIndex + 1);
      setGameStatus('finished');
      toast.success(`Player ${playerIndex + 1} wins!`);
      setMoveHistory(prev => [...prev, `Player ${playerIndex + 1} rolled a ${steps} and reached position ${totalSquares}!`]);
      setPlayers(prev => {
        const newPlayers = [...prev];
        newPlayers[playerIndex] = newPosition;
        return newPlayers;
      });
      return;
    }
    
    // Check if player overshot the board
    if (newPosition > totalSquares) {
      toast.error("You need the exact number to win!");
      setMoveHistory(prev => [...prev, `Player ${playerIndex + 1} rolled a ${steps} but overshot the board.`]);
      switchPlayer();
      return;
    }
    
    // Update player position
    setPlayers(prev => {
      const newPlayers = [...prev];
      newPlayers[playerIndex] = newPosition;
      return newPlayers;
    });
    
    // Add to move history
    setMoveHistory(prev => [...prev, `Player ${playerIndex + 1} rolled a ${steps} and moved to position ${newPosition}.`]);
    
    // Check for snake
    const snake = findSnake(newPosition);
    if (snake) {
      setTimeout(() => {
        toast.error(`Oops! Player ${playerIndex + 1} hit a snake!`);
        setMoveHistory(prev => [...prev, `Player ${playerIndex + 1} hit a snake and slides down to position ${snake.end}.`]);
        
        setPlayers(prev => {
          const newPlayers = [...prev];
          newPlayers[playerIndex] = snake.end;
          return newPlayers;
        });
      }, 1000);
    }
    
    // Check for ladder
    const ladder = findLadder(newPosition);
    if (ladder) {
      setTimeout(() => {
        toast.success(`Yay! Player ${playerIndex + 1} found a ladder!`);
        setMoveHistory(prev => [...prev, `Player ${playerIndex + 1} found a ladder and climbs up to position ${ladder.end}.`]);
        
        // Special case for winning with a ladder
        if (ladder.end === totalSquares) {
          setWinner(playerIndex + 1);
          setGameStatus('finished');
          toast.success(`Player ${playerIndex + 1} wins!`);
        }
        
        setPlayers(prev => {
          const newPlayers = [...prev];
          newPlayers[playerIndex] = ladder.end;
          return newPlayers;
        });
      }, 1000);
    }
    
    // Switch player after the move and any snakes/ladders
    setTimeout(() => {
      if (!snake && !ladder) {
        switchPlayer();
      } else {
        // If there was a snake or ladder, give additional time before switching
        setTimeout(switchPlayer, 500);
      }
    }, snake || ladder ? 1500 : 500);
  };
  
  // Switch to the next player
  const switchPlayer = () => {
    setCurrentPlayer(current => (current % playerCount) + 1);
  };
  
  // Roll the dice
  const rollDice = () => {
    if (winner || isRolling) return;
    
    setGameStatus('playing');
    setIsRolling(true);
    
    // Simulate dice roll animation
    const rollInterval = setInterval(() => {
      setDiceValue(Math.floor(Math.random() * 6) + 1);
    }, 100);
    
    // Stop rolling after some time
    setTimeout(() => {
      clearInterval(rollInterval);
      
      // Get final dice value
      const finalValue = Math.floor(Math.random() * 6) + 1;
      setDiceValue(finalValue);
      setIsRolling(false);
      
      // Move the current player
      movePlayer(currentPlayer - 1, finalValue);
    }, 1000);
  };
  
  // Start a new game
  const newGame = () => {
    setPlayers(Array(playerCount).fill(1));
    setCurrentPlayer(1);
    setDiceValue(0);
    setWinner(null);
    setGameStatus('waiting');
    setMoveHistory([]);
    toast.info("New game started!");
  };
  
  // Reset the game completely
  const resetGame = () => {
    setPlayers(Array(playerCount).fill(1));
    setCurrentPlayer(1);
    setDiceValue(0);
    setWinner(null);
    setGameStatus('waiting');
    setMoveHistory([]);
  };
  
  // Set a custom player count
  const setCustomPlayerCount = (count: number) => {
    if (count >= 2 && count <= 4) {
      setPlayerCount(count);
    }
  };
  
  return {
    boardSize,
    snakes,
    ladders,
    players,
    currentPlayer,
    diceValue,
    isRolling,
    winner,
    gameStatus,
    moveHistory,
    rollDice,
    newGame,
    resetGame,
    setCustomPlayerCount
  };
};
